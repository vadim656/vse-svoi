import Vue from 'vue';
import VueAwesomeSwiper from 'vue-awesome-swiper';

// import custom style
import '@/assets/css/swiper.css';

Vue.use(VueAwesomeSwiper);