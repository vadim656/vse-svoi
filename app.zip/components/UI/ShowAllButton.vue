<template>
    <button class=" border px-[50px] py-[15px] uppercase text-gradient border-[#04BFBF] border-[2px] rounded-xl"><slot></slot></button>
</template>