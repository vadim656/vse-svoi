<template>
  <div>
    <footer class="mt-12 bg-[#202020] text-white h-[200px]">
      <div
        class=" w-full container mx-auto h-full grid grid-cols-1 grid-rows-[1fr,1fr]"
      >
        <div class="w-full flex justify-between items-center">
          <div><img src="../../assets/img/logo-v1.png" alt="" /></div>
          <div>
            <ul class="flex  gap-6 font-18">
              <li>Актуальное</li>
              <li>Услуги</li>
              <li>Контакты</li>
              <li>Интересное</li>
              <li>Сотрудничество</li>
              <li>О нас</li>
            </ul>
          </div>
          <div class="flex">
            <div>
              <img src="../../assets/icons/map.png" alt="">
            </div>
            <div class="ml-4">г.Ставрополь, пирогова 001</div>
          </div>
          <div class=" flex gap-4">
              <a href="/"><img src="../../assets/icons/instagram.png" alt=""></a>
              <a href="/"><img src="../../assets/icons/youtube.png" alt=""></a>
          </div>
        </div>
        <div class="w-full flex justify-between items-center h-full">
          <div class="flex gap-4">
              <img src="../../assets/icons/apple-pay.png" alt="">
              <img src="../../assets/icons/cc-visa.png" alt="">
          </div>
          <a class="font-bold cursor-pointer">Created <span class="text-[#D97904]">Foxsis</span> </a>
        </div>
      </div>
    </footer>
  </div>
</template>
