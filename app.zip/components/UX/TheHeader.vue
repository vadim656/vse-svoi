<template>
  <div class="top-0 sticky z-[99999999] backdrop-blur-md bg-black/30 shadow-3xl">
    <header class="w-full -mt-[100px]">
      <div
        class="flex container w-full justify-between text-white  w-full h-[100px] mx-auto items-center "
      >
        <div class="w-5/12">
          <img src="../../assets/img/logo-v1.png" alt="" />
        </div>
        <div class="flex h-full items-center justify-between w-7/12">
          <div>
              <ul class="flex gap-6 font-18">
                  <li>Актуальное</li>
                  <li>Услуги</li>
                  <li>Контакты</li>
                  <li>Интересное</li>
                  <li>Сотрудничество</li>
                  <li>О нас</li>
              </ul>
          </div>
          <div>
              <img src="../../assets/img/menu.png" alt="">
          </div>
        </div>
      </div>
    </header>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
