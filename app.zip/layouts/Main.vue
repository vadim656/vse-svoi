<template>
  <div>
    <UXTheHeader/>
    <Nuxt />
    <UXTheFooter/>
  </div>
</template>
