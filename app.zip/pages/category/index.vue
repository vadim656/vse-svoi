<template>
  <div class="h-full relative">
    <div class="">
      <img
        class="w-full h-[400px] absolute top-0 left-0 z-[1]"
        src="../../assets/img/category.jpg"
        alt=""
      />
      <div class="flex flex-col z-[99] container mx-auto">
        <div class="uppercase text-[130px] text-white text-left">
          туры в горы
        </div>
        <div
          class="uppercase text-[130px] text-white text-left custom-h1 -mt-12"
        >
          выходного дня
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'Main'
}
</script>
